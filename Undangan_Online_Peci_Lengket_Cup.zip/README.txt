# Undangan Online Peci Lengket Cup

Website undangan liputan untuk Tim Kreator Tualang.

## Publikasi gratis dengan GitHub Pages
1. Buat/login akun GitHub di https://github.com/
2. Buat repository baru, misalnya `undangan-peci-lengket-cup`.
3. Upload file `index.html` ke repository tersebut.
4. Buka **Settings → Pages**.
5. Pada **Build and deployment**, pilih **Deploy from a branch**.
6. Pilih branch `main` dan folder `/ (root)`, lalu Save.
7. Tunggu beberapa menit. GitHub akan memberikan alamat website seperti:
   `https://NAMA-AKUN.github.io/undangan-peci-lengket-cup/`

## Catatan
Tombol lokasi menggunakan link Google Maps yang diberikan panitia.
Tombol konfirmasi WhatsApp diarahkan ke Suhardi. Kontak Zalik juga tersedia di bagian kontak.
